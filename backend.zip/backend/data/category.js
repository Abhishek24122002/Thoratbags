const Category = [
    {
        title: 'Thorat Bags',
        url: 'Thorat-section',
        image: './images/gym.png',
        price: 449,
        description:'This is description of Thorat Bag. Explore More by clicking here'
    },
    {
        title: 'College Bags',
        url: 'college-section',
        image: './img/bags/bag3.png',
        price: 499,
        description:'This is description of College Bag'
    },
    {
        title: 'Camping Bags',
        url: 'camp-section',
        image: './img/bags/bag4.png',
        price: 999,
        description:'When your Laptop is your Every Thing.'
    },
    {
        title: 'Ladies Bags',
        url: 'ladies-section',
        image: './img/bags/bag10.png',
        price: 449,
        description:'This is description of Ladies Bag. Explore by clicking here'
    },  
    {
        title: 'Military Bag',
        url: 'military-section',
        image: './img/bags/mili1.png',
        price: 1499,
        description:'This is description of Military Bags.'
    }

    
]

module.exports = Category
